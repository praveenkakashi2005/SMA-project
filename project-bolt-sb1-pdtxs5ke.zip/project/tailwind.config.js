/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'meme': ['"Anton"', 'Impact', 'sans-serif'],
        'sans': ['"Inter"', 'system-ui', 'sans-serif'],
      },
      colors: {
        'dark': {
          900: '#121212',
          800: '#1E1E1E',
          700: '#2D2D2D',
          600: '#3C3C3C',
        },
        'accent': {
          red: '#FF5252',
          blue: '#00E5FF',
          yellow: '#FFEA00',
          green: '#76FF03',
        },
        'success': {
          100: '#DEFFEE',
          500: '#00C853',
          700: '#00833F',
        },
        'warning': {
          100: '#FFF9E6',
          500: '#FFC107',
          700: '#C79100',
        },
        'error': {
          100: '#FFEBEE',
          500: '#F44336',
          700: '#C62828',
        },
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        wiggle: {
          '0%, 100%': { transform: 'rotate(-3deg)' },
          '50%': { transform: 'rotate(3deg)' },
        },
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        'float-slow': 'float 8s ease-in-out infinite',
        'float-fast': 'float 4s ease-in-out infinite',
        wiggle: 'wiggle 1s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
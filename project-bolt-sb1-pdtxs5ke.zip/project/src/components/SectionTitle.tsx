import React from 'react';
import { motion } from 'framer-motion';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  gradient?: string;
  className?: string;
  align?: 'left' | 'center' | 'right';
}

const SectionTitle: React.FC<SectionTitleProps> = ({ 
  title, 
  subtitle, 
  gradient = 'from-accent-blue to-accent-green',
  className = '',
  align = 'center'
}) => {
  const alignmentClass = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right'
  }[align];

  return (
    <motion.div 
      className={`mb-12 ${alignmentClass} ${className}`}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
    >
      {subtitle && (
        <p className="text-accent-yellow uppercase tracking-wider font-medium mb-2">
          {subtitle}
        </p>
      )}
      
      <h2 className={`gradient-text ${gradient} max-w-3xl mx-auto ${align === 'center' ? 'mx-auto' : align === 'right' ? 'ml-auto' : ''}`}>
        {title}
      </h2>
    </motion.div>
  );
};

export default SectionTitle;
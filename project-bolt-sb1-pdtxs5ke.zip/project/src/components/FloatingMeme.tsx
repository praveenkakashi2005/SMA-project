import React from 'react';
import { motion } from 'framer-motion';

interface FloatingMemeProps {
  src: string;
  alt: string;
  className?: string;
  delay?: number;
  duration?: number;
}

const FloatingMeme: React.FC<FloatingMemeProps> = ({ 
  src, 
  alt, 
  className = '', 
  delay = 0,
  duration = 6
}) => {
  return (
    <motion.div
      className={`absolute ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: [0, 1, 1, 0],
        y: [20, 0, -50, -100],
        x: (Math.random() - 0.5) * 30,
        rotate: [-2, 5, -3, 2]
      }}
      transition={{ 
        duration: duration,
        delay: delay,
        repeat: Infinity,
        repeatType: 'loop',
        times: [0, 0.1, 0.8, 1]
      }}
    >
      <img
        src={src}
        alt={alt}
        className="rounded-lg shadow-xl w-full h-full object-cover"
      />
    </motion.div>
  );
};

export default FloatingMeme;
import React from 'react';
import { Link } from 'react-router-dom';
import { Laugh, Github, Twitter, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-800 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <Link to="/" className="flex items-center space-x-2">
              <Laugh className="w-8 h-8 text-accent-yellow" />
              <span className="font-meme text-xl text-white">MEME VIRALITY</span>
            </Link>
            <p className="mt-4 text-gray-400 max-w-xs">
              Decoding the science of viral content through data analysis and machine learning.
            </p>
            <div className="flex mt-6 space-x-4">
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <Github className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-accent-blue transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-accent-blue transition-colors">
                  About the Project
                </Link>
              </li>
              <li>
                <Link to="/key-findings" className="text-gray-400 hover:text-accent-blue transition-colors">
                  Key Findings
                </Link>
              </li>
              <li>
                <Link to="/try-yourself" className="text-gray-400 hover:text-accent-blue transition-colors">
                  Try It Yourself
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Contact</h4>
            <p className="text-gray-400">Have questions about the meme virality project?</p>
            <a href="mailto:contact@memevirality.com" className="text-accent-blue hover:text-accent-yellow transition-colors mt-2 inline-block">
              contact@memevirality.com
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} Meme Virality Project. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm mx-3">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm mx-3">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
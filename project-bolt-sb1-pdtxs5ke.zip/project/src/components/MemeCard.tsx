import React from 'react';
import { motion } from 'framer-motion';

interface MemeCardProps {
  src: string;
  alt: string;
  caption: string;
  viralityScore?: number;
  source?: string;
  className?: string;
}

const MemeCard: React.FC<MemeCardProps> = ({ 
  src, 
  alt, 
  caption, 
  viralityScore, 
  source,
  className = '' 
}) => {
  return (
    <motion.div
      className={`meme-card ${className}`}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="h-48 overflow-hidden">
        <img 
          src={src} 
          alt={alt} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" 
        />
      </div>
      
      <div className="p-4">
        <p className="font-meme text-lg mb-2 text-white leading-tight">{caption}</p>
        
        {viralityScore !== undefined && (
          <div className="mt-3 mb-2">
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm text-gray-400">Virality Score</span>
              <span className="text-sm font-medium" style={{ 
                color: viralityScore > 75 ? '#76FF03' : 
                       viralityScore > 50 ? '#FFEA00' : 
                       viralityScore > 25 ? '#FF5252' : '#F44336'
              }}>
                {viralityScore}%
              </span>
            </div>
            <div className="w-full bg-dark-600 rounded-full h-1.5">
              <div 
                className="h-1.5 rounded-full" 
                style={{ 
                  width: `${viralityScore}%`, 
                  backgroundColor: viralityScore > 75 ? '#76FF03' : 
                                   viralityScore > 50 ? '#FFEA00' : 
                                   viralityScore > 25 ? '#FF5252' : '#F44336'
                }}
              ></div>
            </div>
          </div>
        )}
        
        {source && (
          <div className="mt-3 text-xs text-gray-500">
            Source: {source}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default MemeCard;
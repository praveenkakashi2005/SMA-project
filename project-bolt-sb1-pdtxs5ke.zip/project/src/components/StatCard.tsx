import React from 'react';
import { motion } from 'framer-motion';

interface StatCardProps {
  value: string;
  label: string;
  color: string;
  delay?: number;
}

const StatCard: React.FC<StatCardProps> = ({ value, label, color, delay = 0 }) => {
  return (
    <motion.div
      className="bg-dark-800 rounded-xl p-6 shadow-lg text-center border border-dark-600"
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
    >
      <h3 
        className="text-3xl md:text-4xl font-bold mb-2" 
        style={{ color }}
      >
        {value}
      </h3>
      <p className="text-gray-400 text-sm uppercase tracking-wider">{label}</p>
    </motion.div>
  );
};

export default StatCard;
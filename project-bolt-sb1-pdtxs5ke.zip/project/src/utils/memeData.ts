export interface Meme {
  id: number;
  src: string;
  alt: string;
  caption: string;
  viralityScore?: number;
  source?: string;
  features?: {
    sentiment: 'positive' | 'negative' | 'neutral';
    complexity: 'simple' | 'medium' | 'complex';
    relatability: number; // 0-100
    humor: number; // 0-100
    trending: boolean;
  };
}

export const sampleMemes: Meme[] = [
  {
    id: 1,
    src: "https://images.pexels.com/photos/3761508/pexels-photo-3761508.jpeg",
    alt: "Confused cat with text",
    caption: "When you finally understand the code you wrote 3 months ago",
    viralityScore: 87,
    source: "Reddit",
    features: {
      sentiment: "positive",
      complexity: "simple",
      relatability: 92,
      humor: 85,
      trending: true
    }
  },
  {
    id: 2,
    src: "https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg",
    alt: "Dog wearing glasses",
    caption: "POV: It's your first day as a data scientist",
    viralityScore: 75,
    source: "Instagram",
    features: {
      sentiment: "neutral",
      complexity: "medium",
      relatability: 78,
      humor: 82,
      trending: true
    }
  },
  {
    id: 3,
    src: "https://images.pexels.com/photos/4587987/pexels-photo-4587987.jpeg",
    alt: "Surprised person",
    caption: "That moment when the ML model actually works on the first try",
    viralityScore: 92,
    source: "Twitter",
    features: {
      sentiment: "positive",
      complexity: "medium",
      relatability: 95,
      humor: 90,
      trending: true
    }
  },
  {
    id: 4,
    src: "https://images.pexels.com/photos/57416/cat-sweet-kitty-animals-57416.jpeg",
    alt: "Sleepy cat",
    caption: "Me before coffee vs. me after coffee",
    viralityScore: 68,
    source: "Facebook",
    features: {
      sentiment: "neutral",
      complexity: "simple",
      relatability: 89,
      humor: 72,
      trending: false
    }
  },
  {
    id: 5,
    src: "https://images.pexels.com/photos/127027/pexels-photo-127027.jpeg",
    alt: "Lion looking majestic",
    caption: "How I think I look in meetings vs. how I actually look",
    viralityScore: 81,
    source: "LinkedIn",
    features: {
      sentiment: "positive",
      complexity: "medium",
      relatability: 86,
      humor: 79,
      trending: true
    }
  },
  {
    id: 6,
    src: "https://images.pexels.com/photos/1310847/pexels-photo-1310847.jpeg",
    alt: "Pug looking confused",
    caption: "When someone asks if I'm still watching Netflix after 8 hours",
    viralityScore: 33,
    source: "Instagram",
    features: {
      sentiment: "negative",
      complexity: "simple",
      relatability: 45,
      humor: 38,
      trending: false
    }
  }
];

export const viralityFactors = [
  {
    factor: "Emotional Response",
    description: "Memes triggering strong emotions (joy, surprise, outrage) are 3.2x more likely to go viral",
    importance: 92,
  },
  {
    factor: "Relatability",
    description: "Content that connects to shared experiences sees 2.7x higher engagement rates",
    importance: 88,
  },
  {
    factor: "Simplicity",
    description: "Memes with clear, instant-understand messages are 1.9x more successful",
    importance: 83,
  },
  {
    factor: "Timing",
    description: "Memes relevant to current events or trends see 4.1x higher spread velocity",
    importance: 79,
  },
  {
    factor: "Humor",
    description: "Funny content receives 2.3x more shares than non-humorous equivalents",
    importance: 75,
  },
  {
    factor: "Uniqueness",
    description: "Novel approaches to familiar formats gain 1.5x more traction",
    importance: 68,
  },
];
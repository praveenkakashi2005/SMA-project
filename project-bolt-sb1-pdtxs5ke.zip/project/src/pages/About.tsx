import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { Lightbulb, Users, BarChart as ChartBar, LineChart } from 'lucide-react';
import FeatureCard from '../components/FeatureCard';

const About: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="About the Project" 
            subtitle="Our Mission"
            gradient="from-accent-yellow to-accent-green"
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-bold mb-4 text-white">Decoding Meme Virality</h3>
              <p className="text-gray-300 mb-6">
                The Meme Virality Prediction project began with a simple question: 
                <span className="font-semibold text-white"> Can we scientifically predict what makes content go viral?</span>
              </p>
              <p className="text-gray-300 mb-6">
                Our team of data scientists, content analysts, and machine learning engineers set out to analyze 
                thousands of memes across social media platforms to identify patterns, trends, and key factors 
                that contribute to viral spread.
              </p>
              <p className="text-gray-300">
                By combining quantitative analysis with qualitative insights, we've developed a predictive model 
                that can estimate a meme's viral potential before it's even posted.
              </p>
            </motion.div>
            
            <motion.div
              className="rounded-xl overflow-hidden shadow-2xl"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <img 
                src="https://images.pexels.com/photos/7014337/pexels-photo-7014337.jpeg" 
                alt="Team analyzing meme data" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Project Goals */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Project Goals" 
            subtitle="What We're Aiming For"
            gradient="from-accent-blue to-accent-red"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard
              title="Analyze Patterns"
              description="Identify common characteristics among memes that achieve widespread popularity across platforms."
              icon={ChartBar}
              color="#00E5FF"
              delay={0}
            />
            
            <FeatureCard
              title="Build Predictive Model"
              description="Develop an AI model that can accurately predict a meme's potential for virality before posting."
              icon={LineChart}
              color="#FF5252"
              delay={0.1}
            />
            
            <FeatureCard
              title="Understand Psychology"
              description="Explore the psychological triggers that make certain content more shareable than others."
              icon={Lightbulb}
              color="#FFEA00"
              delay={0.2}
            />
            
            <FeatureCard
              title="Help Creators"
              description="Provide actionable insights for content creators to improve their meme creation strategy."
              icon={Users}
              color="#76FF03"
              delay={0.3}
            />
          </div>
        </div>
      </section>
      
      {/* Methodology */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Our Methodology" 
            subtitle="The Science Behind the Memes"
            gradient="from-accent-green to-accent-yellow"
          />
          
          <div className="space-y-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-2 lg:order-1"
              >
                <h3 className="text-2xl font-bold mb-4 text-white">Data Collection & Analysis</h3>
                <p className="text-gray-300 mb-4">
                  We collected over 50,000 memes from Reddit, Twitter, Instagram, and Facebook, 
                  tracking their engagement metrics across a 30-day period.
                </p>
                <p className="text-gray-300">
                  Each meme was tagged with metadata including format type, subject matter, text length, 
                  image complexity, color schemes, and emotional sentiment to enable comprehensive analysis.
                </p>
              </motion.div>
              
              <motion.div
                className="rounded-xl overflow-hidden shadow-lg order-1 lg:order-2"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <img 
                  src="https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg" 
                  alt="Data visualization of meme trends" 
                  className="w-full h-full object-cover"
                />
              </motion.div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <motion.div
                className="rounded-xl overflow-hidden shadow-lg"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <img 
                  src="https://images.pexels.com/photos/4974920/pexels-photo-4974920.jpeg" 
                  alt="Machine learning model development" 
                  className="w-full h-full object-cover"
                />
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h3 className="text-2xl font-bold mb-4 text-white">Machine Learning Approach</h3>
                <p className="text-gray-300 mb-4">
                  We developed a multi-factor machine learning model that incorporates both content 
                  analysis (image recognition, text sentiment) and context analysis (timing, current trends).
                </p>
                <p className="text-gray-300">
                  Our model was trained on 80% of our dataset and validated against the remaining 20%, 
                  achieving a prediction accuracy of 78% for memes that would exceed 100,000 engagements.
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="The Team Behind the Meme Science" 
            subtitle="Our Experts"
            gradient="from-accent-red to-accent-blue"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div
              className="bg-dark-800 rounded-xl overflow-hidden shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0 }}
              whileHover={{ y: -5 }}
            >
              <img 
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg" 
                alt="Data Science Lead" 
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h4 className="text-lg font-bold">Dr. Alex Chen</h4>
                <p className="text-accent-blue">Data Science Lead</p>
                <p className="text-gray-400 mt-2 text-sm">
                  Specializing in predictive modeling and social media analysis with 10+ years of experience.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl overflow-hidden shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5 }}
            >
              <img 
                src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg" 
                alt="Content Strategist" 
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h4 className="text-lg font-bold">Maya Rodriguez</h4>
                <p className="text-accent-yellow">Content Strategist</p>
                <p className="text-gray-400 mt-2 text-sm">
                  Former social media director with expertise in viral content patterns and audience behavior.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl overflow-hidden shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5 }}
            >
              <img 
                src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg" 
                alt="ML Engineer" 
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h4 className="text-lg font-bold">James Wilson</h4>
                <p className="text-accent-green">ML Engineer</p>
                <p className="text-gray-400 mt-2 text-sm">
                  Developed the core prediction algorithms using computer vision and NLP techniques.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl overflow-hidden shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5 }}
            >
              <img 
                src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg" 
                alt="UX Researcher" 
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h4 className="text-lg font-bold">Sarah Patel</h4>
                <p className="text-accent-red">UX Researcher</p>
                <p className="text-gray-400 mt-2 text-sm">
                  Conducted studies on user sharing behavior and content engagement patterns.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { ChevronRight, Users, Brain, TrendingUp, Clipboard } from 'lucide-react';
import { Link } from 'react-router-dom';

const Conclusion: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Conclusion" 
            subtitle="Key Takeaways"
            gradient="from-accent-blue to-accent-green"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              Our extensive research into meme virality has revealed consistent patterns and factors 
              that influence how content spreads across social platforms.
            </p>
            <p className="text-gray-400">
              With these insights, creators can approach meme creation with a more scientific understanding 
              of what drives engagement and sharing behavior.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Key Findings Summary */}
      <section className="py-20">
        <div className="section-container">
          <h3 className="text-2xl font-bold mb-10 text-center">Key Takeaways from the Research</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-red to-accent-yellow flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Virality is Predictable</h4>
              <p className="text-gray-300 mb-4">
                Viral spread follows identifiable patterns that can be measured, analyzed, and predicted 
                with significant accuracy.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-red mt-1 flex-shrink-0" />
                  <span>Early engagement velocity is highly predictive of total reach</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-red mt-1 flex-shrink-0" />
                  <span>78% prediction accuracy achieved with our model</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-blue to-accent-green flex items-center justify-center">
                <Users className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Emotional Connection is Key</h4>
              <p className="text-gray-300 mb-4">
                Content that triggers strong emotional responses—positive or negative—spreads significantly faster.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-blue mt-1 flex-shrink-0" />
                  <span>3.2x higher share rates for high-emotion content</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-blue mt-1 flex-shrink-0" />
                  <span>Surprise + joy/outrage creates the strongest response</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-yellow to-accent-green flex items-center justify-center">
                <Clipboard className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Simplicity Beats Complexity</h4>
              <p className="text-gray-300 mb-4">
                Easily digestible content with clear visual focus and short, impactful text consistently performs better.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-yellow mt-1 flex-shrink-0" />
                  <span>Captions under 10 words saw 35% more engagement</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-yellow mt-1 flex-shrink-0" />
                  <span>Clear subject focus outperformed busy compositions</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-red to-accent-blue flex items-center justify-center">
                <Brain className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Relatability Drives Sharing</h4>
              <p className="text-gray-300 mb-4">
                Content that connects to shared experiences or cultural touchpoints has significantly higher spread.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-red mt-1 flex-shrink-0" />
                  <span>2.7x higher engagement for highly relatable content</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-red mt-1 flex-shrink-0" />
                  <span>Universal experiences outperform niche references</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-green to-accent-blue flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Timing is Critical</h4>
              <p className="text-gray-300 mb-4">
                The timing of content posting has a dramatic impact on its potential spread and engagement.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-green mt-1 flex-shrink-0" />
                  <span>4.1x higher engagement for trend-relevant timing</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-green mt-1 flex-shrink-0" />
                  <span>Platform-specific optimal posting times matter</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg border border-dark-600"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.5 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 mb-4 rounded-full bg-gradient-to-br from-accent-blue to-accent-yellow flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-dark-900" />
              </div>
              <h4 className="text-xl font-bold mb-3">Format Familiarity + Novelty</h4>
              <p className="text-gray-300 mb-4">
                The most successful memes balance familiar formats with unexpected twists or innovations.
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-blue mt-1 flex-shrink-0" />
                  <span>47% higher engagement for "familiar but novel" content</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 text-accent-blue mt-1 flex-shrink-0" />
                  <span>Completely new formats face higher adoption barriers</span>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Practical Applications */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Practical Applications" 
            subtitle="Using These Insights"
            gradient="from-accent-yellow to-accent-red"
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-bold mb-6 text-white">For Content Creators</h3>
              <div className="space-y-4">
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-yellow">Strategic Content Planning</h4>
                  <p className="text-gray-300">
                    Use the virality factors to plan content that has higher potential for engagement. 
                    Focus on creating emotionally resonant, simple, and relatable memes with clear visual focus.
                  </p>
                </div>
                
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-yellow">Optimized Posting Schedules</h4>
                  <p className="text-gray-300">
                    Time posts to align with platform peak activity times and current trend cycles. 
                    Our research shows specific posting windows can increase engagement by up to 42%.
                  </p>
                </div>
                
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-yellow">Content Testing</h4>
                  <p className="text-gray-300">
                    Use our prediction model to pre-test memes before posting, allowing for 
                    optimization and refinement before sharing with your audience.
                  </p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-bold mb-6 text-white">For Marketers & Brands</h3>
              <div className="space-y-4">
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-green">Data-Driven Meme Marketing</h4>
                  <p className="text-gray-300">
                    Incorporate viral factors into marketing campaigns that use meme formats. 
                    Our research provides specific guidelines for creating branded content with higher share potential.
                  </p>
                </div>
                
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-green">Trend Monitoring</h4>
                  <p className="text-gray-300">
                    Use our insights on trend cycles to better anticipate and capitalize on emerging 
                    meme formats and cultural moments relevant to your brand.
                  </p>
                </div>
                
                <div className="bg-dark-900 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-accent-green">Audience Resonance</h4>
                  <p className="text-gray-300">
                    Better understand what types of content resonate most with different demographic 
                    segments, allowing for more targeted and effective meme-based marketing.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Future Research */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Future Research Directions" 
            subtitle="What's Next"
            gradient="from-accent-green to-accent-blue"
          />
          
          <motion.div
            className="max-w-3xl mx-auto bg-dark-800 rounded-xl p-8 shadow-xl"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-gray-300 mb-6">
              While our research has revealed significant insights into meme virality, several areas warrant further investigation:
            </p>
            
            <ul className="space-y-4 mb-6">
              <li className="flex items-start">
                <span className="text-accent-blue mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Cross-Platform Dynamics:</strong> Deeper analysis of how memes evolve 
                  as they move across different platforms and audience demographics
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-blue mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Video Meme Analysis:</strong> Extending our research methodology to short-form 
                  video memes on platforms like TikTok and Instagram Reels
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-blue mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Cultural Differences:</strong> Investigating how meme virality factors 
                  vary across different countries, languages, and cultural contexts
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-blue mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Long-term Meme Evolution:</strong> Studying how successful meme formats 
                  evolve over months and years, identifying factors that contribute to longevity versus short-lived viral moments
                </span>
              </li>
            </ul>
            
            <p className="text-accent-green">
              Our team will continue expanding this research to build more sophisticated prediction 
              models and deeper insights into viral content dynamics.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Final Call to Action */}
      <section className="py-24 bg-dark-800 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          {/* Background pattern */}
          <div className="absolute w-full h-full">
            {Array.from({ length: 12 }).map((_, i) => (
              <div 
                key={i}
                className="absolute rounded-full"
                style={{
                  width: `${Math.random() * 300 + 50}px`,
                  height: `${Math.random() * 300 + 50}px`,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  background: i % 4 === 0 ? 'rgba(255, 82, 82, 0.2)' : 
                               i % 4 === 1 ? 'rgba(0, 229, 255, 0.2)' :
                               i % 4 === 2 ? 'rgba(255, 234, 0, 0.2)' :
                                             'rgba(118, 255, 3, 0.2)',
                  filter: 'blur(50px)',
                  transform: `scale(${Math.random() * 0.5 + 0.5})`,
                }}
              />
            ))}
          </div>
        </div>
        
        <div className="section-container relative z-10">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text from-accent-blue to-accent-red">
              Ready to Create Viral Memes?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Apply our research findings to your content strategy and use our prediction 
              model to optimize your memes for maximum engagement.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link 
                to="/try-yourself" 
                className="button-primary text-lg px-10 py-4 inline-flex items-center"
              >
                Try the Predictor <TrendingUp className="ml-2 w-5 h-5" />
              </Link>
              <Link 
                to="/key-findings" 
                className="button-secondary text-lg px-10 py-4 inline-flex items-center"
              >
                Review Key Findings <Clipboard className="ml-2 w-5 h-5" />
              </Link>
            </div>
            
            <p className="mt-8 text-gray-400">
              Have questions or want to collaborate on meme research? 
              <a href="mailto:contact@memevirality.com" className="text-accent-blue hover:text-accent-yellow ml-1">
                Contact our team
              </a>
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Conclusion;
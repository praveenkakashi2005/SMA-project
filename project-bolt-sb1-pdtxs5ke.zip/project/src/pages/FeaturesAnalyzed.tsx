import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { Heart, Eye, Clock, Laugh, Zap, Lightbulb, BarChart, Image } from 'lucide-react';
import FeatureCard from '../components/FeatureCard';

const FeaturesAnalyzed: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Features We Analyzed" 
            subtitle="The Meme Breakdown"
            gradient="from-accent-blue to-accent-red"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              We examined multiple dimensions of each meme to understand what drives virality. 
              Our analysis considered both content factors and contextual elements.
            </p>
            <p className="text-gray-400">
              By analyzing these features across thousands of memes, we identified distinct patterns 
              that separate viral content from content that fails to gain traction.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Sentiment Analysis */}
      <section className="py-20">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="gradient-text from-accent-yellow to-accent-red text-3xl font-bold mb-6">
                Emotional Impact & Sentiment
              </h3>
              <p className="text-gray-300 mb-4">
                We used natural language processing and image recognition to classify the emotional 
                content of each meme, categorizing them along several dimensions:
              </p>
              <ul className="text-gray-400 space-y-4 mb-6">
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Heart className="w-5 h-5 text-accent-red" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Emotional Valence</strong>
                    <span>Positive, negative, or neutral emotional tone, measured on a -10 to +10 scale</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Laugh className="w-5 h-5 text-accent-yellow" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Humor Type</strong>
                    <span>Categorized as sarcasm, irony, absurdism, puns, or reference humor</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Zap className="w-5 h-5 text-accent-blue" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Emotional Intensity</strong>
                    <span>Strength of emotional reaction on a 1-10 scale, based on language and imagery</span>
                  </div>
                </li>
              </ul>
              <p className="text-gray-300">
                Our findings showed that memes eliciting strong emotional responses—whether positive
                or negative—spread faster than neutral content. Surprisingly, high-arousal negative emotions
                like outrage often spread faster than positive content.
              </p>
            </motion.div>
            
            <motion.div
              className="relative rounded-xl overflow-hidden shadow-2xl h-[400px]"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-yellow/20 to-accent-red/20"></div>
              <img 
                src="https://images.pexels.com/photos/3807738/pexels-photo-3807738.jpeg" 
                alt="Sentiment analysis visualization" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-dark-900/80 backdrop-blur-sm p-6 rounded-xl max-w-xs">
                  <h4 className="text-xl font-bold mb-2 text-white">Key Finding</h4>
                  <p className="text-gray-300">
                    Memes evoking surprise combined with either joy or outrage had 
                    <span className="text-accent-yellow font-bold"> 3.2x higher</span> share rates 
                    than emotionally neutral content.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Visual Content Analysis */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              className="relative rounded-xl overflow-hidden shadow-2xl h-[400px] order-2 lg:order-1"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-blue/20 to-accent-green/20"></div>
              <img 
                src="https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg" 
                alt="Image content analysis" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-dark-900/80 backdrop-blur-sm p-6 rounded-xl max-w-xs">
                  <h4 className="text-xl font-bold mb-2 text-white">Key Finding</h4>
                  <p className="text-gray-300">
                    Memes with recognizable subjects but unexpected contexts were
                    <span className="text-accent-green font-bold"> 2.7x more likely</span> to 
                    go viral than purely random imagery.
                  </p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="order-1 lg:order-2"
            >
              <h3 className="gradient-text from-accent-blue to-accent-green text-3xl font-bold mb-6">
                Image Content & Visual Elements
              </h3>
              <p className="text-gray-300 mb-4">
                Using computer vision and image recognition, we analyzed visual elements of memes:
              </p>
              <ul className="text-gray-400 space-y-4 mb-6">
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Image className="w-5 h-5 text-accent-blue" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Image Complexity</strong>
                    <span>Measured by color variety, subject count, and background complexity</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Eye className="w-5 h-5 text-accent-green" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Subject Recognition</strong>
                    <span>Whether the image contains recognizable people, characters, or objects</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Lightbulb className="w-5 h-5 text-accent-yellow" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Visual Contrast</strong>
                    <span>The use of juxtaposition, unexpected elements, or visual paradoxes</span>
                  </div>
                </li>
              </ul>
              <p className="text-gray-300">
                Surprisingly, our analysis found that image quality was not strongly correlated with virality. 
                Low-resolution or imperfect images often performed just as well as high-quality content, 
                especially when the imperfection appeared intentional.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Context & Timing */}
      <section className="py-20">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="gradient-text from-accent-green to-accent-yellow text-3xl font-bold mb-6">
                Context, Timing & Cultural Relevance
              </h3>
              <p className="text-gray-300 mb-4">
                The context in which a meme appears proved to be a critical factor in its success:
              </p>
              <ul className="text-gray-400 space-y-4 mb-6">
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Clock className="w-5 h-5 text-accent-green" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Timing & Current Events</strong>
                    <span>Correlation with news events, holidays, or trending topics</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <BarChart className="w-5 h-5 text-accent-yellow" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Platform Trends</strong>
                    <span>Alignment with platform-specific trends and popular formats</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Zap className="w-5 h-5 text-accent-red" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Cultural References</strong>
                    <span>Connection to pop culture, subcultures, and niche interests</span>
                  </div>
                </li>
              </ul>
              <p className="text-gray-300">
                Memes referencing current events experienced a much higher immediate spread rate but often had a 
                shorter lifespan. In contrast, memes addressing universal experiences showed longer-term virality.
              </p>
            </motion.div>
            
            <motion.div
              className="relative rounded-xl overflow-hidden shadow-2xl h-[400px]"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-green/20 to-accent-yellow/20"></div>
              <img 
                src="https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg" 
                alt="Timing and context analysis" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-dark-900/80 backdrop-blur-sm p-6 rounded-xl max-w-xs">
                  <h4 className="text-xl font-bold mb-2 text-white">Key Finding</h4>
                  <p className="text-gray-300">
                    Memes posted within 2 hours of a trending event saw 
                    <span className="text-accent-red font-bold"> 4.1x higher</span> engagement 
                    than similar content posted after 24 hours.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Other Features */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Additional Analyzed Features" 
            subtitle="Beyond the Basics"
            gradient="from-accent-red to-accent-blue"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              title="Text Length & Formatting"
              description="Brief captions (under 10 words) with high-contrast text performed 35% better than longer text. ALL CAPS and unusual punctuation increased engagement."
              icon={BarChart}
              color="#FF5252"
              delay={0}
            />
            
            <FeatureCard
              title="Format Familiarity"
              description="Memes using established formats but with novel twists saw 47% higher engagement than completely new formats."
              icon={Image}
              color="#00E5FF"
              delay={0.1}
            />
            
            <FeatureCard
              title="Cross-Platform Appeal"
              description="Content that performed well across multiple platforms showed stronger resilience and longer viral cycles."
              icon={Zap}
              color="#FFEA00"
              delay={0.2}
            />
            
            <FeatureCard
              title="Initial Velocity"
              description="Memes gaining 1000+ engagements in their first hour had an 82% chance of achieving viral status (100k+ engagements)."
              icon={Clock}
              color="#76FF03"
              delay={0.3}
            />
            
            <FeatureCard
              title="Creator Influence"
              description="Original poster's follower count had diminishing returns after 10k followers, suggesting content quality matters more than creator size."
              icon={Heart}
              color="#FF5252"
              delay={0.4}
            />
            
            <FeatureCard
              title="Sharing Context"
              description="Memes shared with personal commentary were 28% more likely to be reshared than those shared without comment."
              icon={Lightbulb}
              color="#00E5FF"
              delay={0.5}
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default FeaturesAnalyzed;
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, TrendingUp, Laugh, Zap } from 'lucide-react';
import FloatingMeme from '../components/FloatingMeme';
import { sampleMemes } from '../utils/memeData';

const Home: React.FC = () => {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="pt-32 pb-20 relative min-h-screen flex items-center">
        <div className="absolute inset-0 overflow-hidden">
          {/* Floating Memes */}
          <FloatingMeme
            src={sampleMemes[0].src}
            alt={sampleMemes[0].alt}
            className="w-32 md:w-48 top-1/4 right-[15%] opacity-70"
            delay={0}
          />
          <FloatingMeme
            src={sampleMemes[1].src}
            alt={sampleMemes[1].alt}
            className="w-24 md:w-40 top-1/2 left-[10%] opacity-60"
            delay={2}
            duration={8}
          />
          <FloatingMeme
            src={sampleMemes[2].src}
            alt={sampleMemes[2].alt}
            className="w-28 md:w-36 bottom-1/4 right-[25%] opacity-50"
            delay={4}
            duration={7}
          />
          <FloatingMeme
            src={sampleMemes[3].src}
            alt={sampleMemes[3].alt}
            className="w-20 md:w-32 top-1/3 left-[25%] opacity-40"
            delay={1.5}
            duration={9}
          />
          
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-900/95 to-dark-900 z-10"></div>
        </div>
        
        <div className="section-container relative z-20">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6 leading-none">
              <span className="gradient-text from-accent-red to-accent-yellow block mb-2">
                Meme Virality Prediction
              </span>
              <span className="text-2xl md:text-3xl font-light text-gray-300">
                What Makes a Meme Go Viral?
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl mb-8 text-gray-300 max-w-2xl mx-auto">
              Decoding the science of viral content through data analysis and machine learning
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/about" className="button-primary flex items-center justify-center">
                Explore the Project <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link to="/try-yourself" className="button-secondary flex items-center justify-center">
                Test Your Meme <Zap className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Features Highlight */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <div className="text-center mb-12">
            <h2 className="mb-4 gradient-text from-accent-blue to-accent-green">Meme Science Features</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our comprehensive analysis breaks down what truly makes content go viral across social platforms
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-dark-900 p-8 rounded-xl border border-dark-700"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              whileHover={{ y: -5, boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}
            >
              <TrendingUp className="w-12 h-12 text-accent-yellow mb-4" />
              <h3 className="text-xl font-bold mb-2">Trend Analysis</h3>
              <p className="text-gray-400">
                Discover patterns across thousands of viral memes and understand what factors consistently drive sharing behavior.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-dark-900 p-8 rounded-xl border border-dark-700"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}
            >
              <Laugh className="w-12 h-12 text-accent-red mb-4" />
              <h3 className="text-xl font-bold mb-2">Content Factors</h3>
              <p className="text-gray-400">
                Explore how humor types, visual elements, and text formatting influence a meme's potential to spread.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-dark-900 p-8 rounded-xl border border-dark-700"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              whileHover={{ y: -5, boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}
            >
              <Zap className="w-12 h-12 text-accent-green mb-4" />
              <h3 className="text-xl font-bold mb-2">Prediction Engine</h3>
              <p className="text-gray-400">
                Our machine learning model predicts viral potential before you post, helping creators optimize their content.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-24 relative">
        <div className="absolute inset-0 overflow-hidden opacity-20">
          {/* Background pattern */}
          <div className="absolute w-full h-full">
            {Array.from({ length: 12 }).map((_, i) => (
              <div 
                key={i}
                className="absolute rounded-full"
                style={{
                  width: `${Math.random() * 300 + 50}px`,
                  height: `${Math.random() * 300 + 50}px`,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  background: i % 4 === 0 ? 'rgba(255, 82, 82, 0.2)' : 
                               i % 4 === 1 ? 'rgba(0, 229, 255, 0.2)' :
                               i % 4 === 2 ? 'rgba(255, 234, 0, 0.2)' :
                                             'rgba(118, 255, 3, 0.2)',
                  filter: 'blur(50px)',
                  transform: `scale(${Math.random() * 0.5 + 0.5})`,
                }}
              />
            ))}
          </div>
        </div>
        
        <div className="section-container relative z-10">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text from-accent-yellow to-accent-red">
              Ready to Optimize Your Meme Game?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Upload your meme and get instant feedback on its viral potential with our AI-powered prediction model.
            </p>
            <Link 
              to="/try-yourself" 
              className="button-primary text-lg px-10 py-4 inline-flex items-center"
            >
              Try It Now <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { Brain, LineChart, FileCode, BarChart4, Database, Zap } from 'lucide-react';
import FeatureCard from '../components/FeatureCard';

const PredictionModel: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Prediction Model" 
            subtitle="The Science Behind Virality Prediction"
            gradient="from-accent-blue to-accent-green"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              We built a sophisticated machine learning model that can predict a meme's viral 
              potential before it's even posted.
            </p>
            <p className="text-gray-400">
              This model analyzes dozens of features across content, context, and timing to 
              generate a virality score from 0-100.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Model Overview */}
      <section className="py-20">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="gradient-text from-accent-yellow to-accent-red text-3xl font-bold mb-6">
                Model Architecture
              </h3>
              <p className="text-gray-300 mb-4">
                Our predictive system combines multiple machine learning approaches:
              </p>
              <ul className="text-gray-400 space-y-4 mb-6">
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Brain className="w-5 h-5 text-accent-yellow" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Computer Vision Analysis</strong>
                    <span>Convolutional neural networks (CNNs) extract visual features from meme images</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <FileCode className="w-5 h-5 text-accent-blue" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Natural Language Processing</strong>
                    <span>BERT-based model analyzes text content for sentiment, complexity and humor</span>
                  </div>
                </li>
                <li className="flex items-start">
                  <span className="bg-dark-700 p-2 rounded-full mr-3 flex-shrink-0">
                    <Database className="w-5 h-5 text-accent-red" />
                  </span>
                  <div>
                    <strong className="text-white block mb-1">Context Analyzer</strong>
                    <span>Time-series analysis of current trends, events, and platform-specific patterns</span>
                  </div>
                </li>
              </ul>
              <p className="text-gray-300">
                These three systems feed into a gradient-boosted decision tree model that combines 
                their outputs with additional metadata to produce the final virality prediction score.
              </p>
            </motion.div>
            
            <motion.div
              className="relative rounded-xl overflow-hidden shadow-2xl h-[400px]"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-blue/20 to-accent-green/20"></div>
              <img 
                src="https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg" 
                alt="Neural network visualization" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-dark-900/80 backdrop-blur-sm p-6 rounded-xl max-w-xs">
                  <h4 className="text-xl font-bold mb-2 text-white">Model Accuracy</h4>
                  <p className="text-gray-300">
                    Our model achieves 
                    <span className="text-accent-green font-bold"> 78% accuracy</span> in predicting 
                    whether a meme will exceed 100,000 engagements.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Feature Importance */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Feature Importance" 
            subtitle="What Our Model Looks For"
            gradient="from-accent-green to-accent-blue"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <motion.div
              className="bg-dark-900 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center mb-4">
                <LineChart className="w-8 h-8 text-accent-blue mr-3" />
                <h3 className="text-xl font-bold">Content Feature Importance</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Emotional Response Intensity</span>
                    <span className="text-sm text-accent-blue">24%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '24%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Relatability Factor</span>
                    <span className="text-sm text-accent-blue">21%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '21%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Image Clarity & Focus</span>
                    <span className="text-sm text-accent-blue">16%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '16%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Text Brevity & Impact</span>
                    <span className="text-sm text-accent-blue">14%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '14%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Format Familiarity</span>
                    <span className="text-sm text-accent-blue">11%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '11%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Other Factors</span>
                    <span className="text-sm text-accent-blue">14%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-blue h-2 rounded-full" style={{ width: '14%' }}></div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              className="bg-dark-900 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="flex items-center mb-4">
                <BarChart4 className="w-8 h-8 text-accent-green mr-3" />
                <h3 className="text-xl font-bold">Context Feature Importance</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Posting Time Optimization</span>
                    <span className="text-sm text-accent-green">26%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '26%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Current Event Relevance</span>
                    <span className="text-sm text-accent-green">22%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '22%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Platform Audience Alignment</span>
                    <span className="text-sm text-accent-green">18%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '18%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Initial Distribution Network</span>
                    <span className="text-sm text-accent-green">15%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '15%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Ongoing Trend Alignment</span>
                    <span className="text-sm text-accent-green">12%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '12%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Other Factors</span>
                    <span className="text-sm text-accent-green">7%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-accent-green h-2 rounded-full" style={{ width: '7%' }}></div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Prediction Process */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="The Prediction Process" 
            subtitle="How It Works"
            gradient="from-accent-red to-accent-yellow"
          />
          
          <div className="relative">
            {/* Connecting line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-dark-600 hidden md:block" style={{ transform: 'translateX(-50%)' }}></div>
            
            <div className="space-y-12">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-6 relative"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="md:text-right md:pr-10">
                  <h3 className="text-xl font-bold mb-2 text-accent-yellow">1. Image & Text Analysis</h3>
                  <p className="text-gray-300">
                    The model processes the meme image and any text content. For images, it identifies 
                    objects, expressions, composition, and visual elements. For text, it evaluates sentiment, 
                    complexity, humor style, and cultural references.
                  </p>
                </div>
                
                <div className="hidden md:block"></div>
                
                {/* Step indicator */}
                <div className="absolute left-1/2 top-6 w-10 h-10 bg-accent-yellow rounded-full flex items-center justify-center hidden md:flex" style={{ transform: 'translateX(-50%)' }}>
                  <span className="text-dark-900 font-bold">1</span>
                </div>
              </motion.div>
              
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-6 relative"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="hidden md:block"></div>
                
                <div className="md:pl-10">
                  <h3 className="text-xl font-bold mb-2 text-accent-blue">2. Context Evaluation</h3>
                  <p className="text-gray-300">
                    The system analyzes current trends and events across social platforms. 
                    It identifies relevant conversations, trending topics, and platform-specific 
                    patterns that might affect how the meme will be received.
                  </p>
                </div>
                
                {/* Step indicator */}
                <div className="absolute left-1/2 top-6 w-10 h-10 bg-accent-blue rounded-full flex items-center justify-center hidden md:flex" style={{ transform: 'translateX(-50%)' }}>
                  <span className="text-dark-900 font-bold">2</span>
                </div>
              </motion.div>
              
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-6 relative"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <div className="md:text-right md:pr-10">
                  <h3 className="text-xl font-bold mb-2 text-accent-green">3. Audience Matching</h3>
                  <p className="text-gray-300">
                    The model determines which demographic segments are most likely to engage with 
                    the content. It considers factors like age groups, interests, and platform preferences 
                    to estimate potential reach.
                  </p>
                </div>
                
                <div className="hidden md:block"></div>
                
                {/* Step indicator */}
                <div className="absolute left-1/2 top-6 w-10 h-10 bg-accent-green rounded-full flex items-center justify-center hidden md:flex" style={{ transform: 'translateX(-50%)' }}>
                  <span className="text-dark-900 font-bold">3</span>
                </div>
              </motion.div>
              
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-6 relative"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <div className="hidden md:block"></div>
                
                <div className="md:pl-10">
                  <h3 className="text-xl font-bold mb-2 text-accent-red">4. Score Generation</h3>
                  <p className="text-gray-300">
                    All factors are weighted and combined to generate a virality score from 0-100. 
                    The model also provides a confidence interval and specific recommendations for 
                    optimizing the content for better performance.
                  </p>
                </div>
                
                {/* Step indicator */}
                <div className="absolute left-1/2 top-6 w-10 h-10 bg-accent-red rounded-full flex items-center justify-center hidden md:flex" style={{ transform: 'translateX(-50%)' }}>
                  <span className="text-dark-900 font-bold">4</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Technical Details */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Technical Specifications" 
            subtitle="Under the Hood"
            gradient="from-accent-blue to-accent-red"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              title="Model Architecture"
              description="Ensemble model combining CNN for images, BERT for text analysis, and XGBoost for final prediction, with 128 million parameters."
              icon={Brain}
              color="#FF5252"
              delay={0}
            />
            
            <FeatureCard
              title="Training Dataset"
              description="50,000 memes with labeled virality outcomes, split 80/20 for training and validation, with regular retraining on new data."
              icon={Database}
              color="#00E5FF"
              delay={0.1}
            />
            
            <FeatureCard
              title="Inference Time"
              description="Average prediction generation in <500ms, allowing for real-time feedback in the user interface."
              icon={Zap}
              color="#FFEA00"
              delay={0.2}
            />
            
            <FeatureCard
              title="Accuracy Metrics"
              description="78% accuracy in viral classification (>100k engagements), with 82% precision and 74% recall for viral content."
              icon={LineChart}
              color="#76FF03"
              delay={0.3}
            />
            
            <FeatureCard
              title="Continuous Learning"
              description="Model incorporates feedback loops from actual outcomes to improve future predictions via reinforcement learning."
              icon={FileCode}
              color="#FF5252"
              delay={0.4}
            />
            
            <FeatureCard
              title="Platform Optimization"
              description="Specialized sub-models for platform-specific predictions (Twitter, Instagram, Reddit, Facebook) with unique weightings."
              icon={BarChart4}
              color="#00E5FF"
              delay={0.5}
            />
          </div>
        </div>
      </section>
      
      {/* Future Improvements */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Future Improvements" 
            subtitle="What's Next"
            gradient="from-accent-green to-accent-yellow"
          />
          
          <motion.div
            className="max-w-3xl mx-auto bg-dark-800 rounded-xl p-8 shadow-xl"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-gray-300 mb-6">
              Our team is continuously working to improve the prediction model. Upcoming enhancements include:
            </p>
            
            <ul className="space-y-4 mb-6">
              <li className="flex items-start">
                <span className="text-accent-green mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Real-time trend integration</strong> to adjust predictions based on emerging topics within minutes
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-green mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Multi-platform optimization</strong> to suggest platform-specific variations for the same core meme
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-green mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Creator-specific modeling</strong> that learns from individual posting histories for personalized predictions
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-green mr-2 font-bold">•</span>
                <span>
                  <strong className="text-white">Video meme analysis</strong> capability to predict virality for short-form video content
                </span>
              </li>
            </ul>
            
            <p className="text-accent-blue">
              With these improvements, we anticipate increasing our prediction accuracy to over 85% by the end of the year.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default PredictionModel;
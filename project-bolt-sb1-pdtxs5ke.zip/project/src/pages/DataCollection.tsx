import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import MemeCard from '../components/MemeCard';
import { sampleMemes } from '../utils/memeData';
import { Twitter, Instagram, Facebook, MessageSquare } from 'lucide-react';
import StatCard from '../components/StatCard';

const DataCollection: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Data Collection" 
            subtitle="Sources & Methodology"
            gradient="from-accent-yellow to-accent-red"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              To build our meme virality prediction model, we gathered a diverse dataset from major 
              social media platforms, tracking engagement metrics and content features.
            </p>
            <p className="text-gray-400">
              Our collection phase spanned 6 months, ensuring we captured seasonal trends and viral 
              cycles across different platforms and audience demographics.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard 
              value="50,000+" 
              label="Memes Analyzed" 
              color="#FF5252"
              delay={0}
            />
            <StatCard 
              value="4" 
              label="Major Platforms" 
              color="#00E5FF"
              delay={0.1}
            />
            <StatCard 
              value="6 Months" 
              label="Collection Period" 
              color="#FFEA00"
              delay={0.2}
            />
            <StatCard 
              value="87%" 
              label="Data Accuracy" 
              color="#76FF03"
              delay={0.3}
            />
          </div>
        </div>
      </section>
      
      {/* Data Sources */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Our Data Sources" 
            subtitle="Where We Looked"
            gradient="from-accent-blue to-accent-green"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <motion.div
              className="bg-dark-800 rounded-xl p-8 border border-dark-600"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center mb-6">
                <Twitter className="w-10 h-10 text-[#1DA1F2] mr-4" />
                <h3 className="text-2xl font-bold">Twitter/X</h3>
              </div>
              <p className="text-gray-300 mb-4">
                We collected 15,000+ memes from Twitter, focusing on engagement metrics like retweets, 
                likes, and reply counts. Trending hashtags were monitored daily to capture emerging meme formats.
              </p>
              <ul className="text-gray-400 space-y-2">
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2">•</span>
                  Main metrics: Retweets, likes, replies, quote tweets
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2">•</span>
                  Average follower count: 22,500
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2">•</span>
                  Peak posting times: 9am, 12pm, 6pm EST
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-8 border border-dark-600"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center mb-6">
                <Instagram className="w-10 h-10 text-[#E1306C] mr-4" />
                <h3 className="text-2xl font-bold">Instagram</h3>
              </div>
              <p className="text-gray-300 mb-4">
                Our Instagram dataset included 12,000+ memes from public accounts, with engagement measured 
                through likes, comments, shares, and saves. We focused on both feed posts and stories.
              </p>
              <ul className="text-gray-400 space-y-2">
                <li className="flex items-start">
                  <span className="text-accent-red mr-2">•</span>
                  Main metrics: Likes, comments, shares, saves
                </li>
                <li className="flex items-start">
                  <span className="text-accent-red mr-2">•</span>
                  Post types: Feed posts, stories, reels
                </li>
                <li className="flex items-start">
                  <span className="text-accent-red mr-2">•</span>
                  Most engaged hashtags: #memes, #funny, #relatable
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-8 border border-dark-600"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="flex items-center mb-6">
                <Facebook className="w-10 h-10 text-[#1877F2] mr-4" />
                <h3 className="text-2xl font-bold">Facebook</h3>
              </div>
              <p className="text-gray-300 mb-4">
                We analyzed 10,000+ memes from public Facebook pages and groups, tracking reactions, 
                comments, and shares. Cross-platform sharing patterns were particularly valuable.
              </p>
              <ul className="text-gray-400 space-y-2">
                <li className="flex items-start">
                  <span className="text-accent-yellow mr-2">•</span>
                  Main metrics: Reactions, comments, shares
                </li>
                <li className="flex items-start">
                  <span className="text-accent-yellow mr-2">•</span>
                  Demographic focus: 25-45 age group
                </li>
                <li className="flex items-start">
                  <span className="text-accent-yellow mr-2">•</span>
                  Content types: Images, GIFs, short videos
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-8 border border-dark-600"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="flex items-center mb-6">
                <MessageSquare className="w-10 h-10 text-[#FF4500] mr-4" />
                <h3 className="text-2xl font-bold">Reddit</h3>
              </div>
              <p className="text-gray-300 mb-4">
                Our Reddit dataset included 13,000+ memes from popular subreddits like r/memes, r/dankmemes, 
                and r/wholesomememes, with upvotes, comments, and awards tracked.
              </p>
              <ul className="text-gray-400 space-y-2">
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  Main metrics: Upvotes, comments, awards
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  Top subreddits: r/memes, r/dankmemes, r/wholesomememes
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  Content origin: 42% of viral memes appeared on Reddit first
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Sample Memes */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Sample Meme Collection" 
            subtitle="From Our Dataset"
            gradient="from-accent-green to-accent-yellow"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="mb-12 max-w-3xl mx-auto text-center"
          >
            <p className="text-gray-300">
              Below are samples from our dataset showing varying levels of virality. We tracked metrics like 
              engagement rate, share velocity, and audience demographics for each meme.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sampleMemes.map((meme, index) => (
              <motion.div
                key={meme.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <MemeCard 
                  src={meme.src}
                  alt={meme.alt}
                  caption={meme.caption}
                  viralityScore={meme.viralityScore}
                  source={meme.source}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Methodology */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Collection Methodology" 
            subtitle="How We Gathered Data"
            gradient="from-accent-red to-accent-blue"
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-bold mb-4 text-white">Automated Collection Process</h3>
              <p className="text-gray-300 mb-4">
                We developed custom web scrapers and utilized platform APIs to collect memes at scale. 
                Each meme was indexed with metadata including:
              </p>
              <ul className="text-gray-400 space-y-3 mb-6">
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">1.</span>
                  <span>
                    <strong className="text-white">Source platform</strong> and original poster information
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">2.</span>
                  <span>
                    <strong className="text-white">Timestamp</strong> of first appearance and peak engagement
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">3.</span>
                  <span>
                    <strong className="text-white">Engagement metrics</strong> tracked hourly for the first 48 hours
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">4.</span>
                  <span>
                    <strong className="text-white">Content features</strong> including text, image content, and format
                  </span>
                </li>
              </ul>
              <p className="text-gray-400">
                All collection was performed in compliance with each platform's terms of service, 
                focusing exclusively on public content.
              </p>
            </motion.div>
            
            <motion.div
              className="rounded-xl overflow-hidden shadow-xl"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <img 
                src="https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg" 
                alt="Data collection methodology diagram" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DataCollection;
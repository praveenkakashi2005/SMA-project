import React, { useState } from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { Upload, X, ArrowRight, Image as ImageIcon, MessageSquare, Zap, Clock } from 'lucide-react';

const TryYourself: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{
    score: number;
    feedback: string[];
    strengths: string[];
    improvements: string[];
  } | null>(null);
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target) {
          setImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };
  
  const clearImage = () => {
    setImage(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);
    
    // Simulate analysis delay
    setTimeout(() => {
      // Generate a random score between 35 and 95
      const score = Math.floor(Math.random() * (95 - 35 + 1)) + 35;
      
      // Simulated results based on score
      const result = {
        score,
        feedback: [
          caption.length > 20 ? "Caption may be too long for optimal engagement" : "Caption length is optimal",
          score > 70 ? "Strong emotional appeal detected" : "Limited emotional connection",
          "Content appears to be " + (score > 60 ? "highly relatable" : "somewhat niche"),
        ],
        strengths: [
          score > 80 ? "Excellent visual clarity" : "Decent visual elements",
          caption.includes("when") ? "Relatable 'when...' format works well" : "Simple and direct messaging",
          score > 70 ? "Good use of contrast in imagery" : "Clear subject focus",
        ],
        improvements: [
          score < 70 ? "Consider a more emotionally evocative caption" : "Minor tweaks to text formatting could help",
          score < 75 ? "Image could benefit from higher contrast" : "Consider adding subtle visual elements",
          "Optimal posting times: 9am or 8pm EST",
        ],
      };
      
      setResult(result);
      setIsAnalyzing(false);
    }, 3000);
  };
  
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Try It Yourself" 
            subtitle="Test Your Meme"
            gradient="from-accent-red to-accent-blue"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              Upload your meme and see its predicted virality score. Our model will analyze 
              your content and provide feedback on how to improve its viral potential.
            </p>
            <p className="text-gray-400">
              <span className="text-accent-yellow">Note:</span> This is a simulation of our prediction model. 
              In a real implementation, we would analyze your meme against our full dataset and algorithm.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Try It Form */}
      <section className="py-16">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="bg-dark-800 rounded-xl p-8 shadow-xl">
              <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                  <label className="block text-white font-medium mb-2">Upload Meme Image</label>
                  
                  {!image ? (
                    <div className="border-2 border-dashed border-dark-600 rounded-lg p-8 text-center">
                      <input 
                        type="file" 
                        id="image-upload" 
                        accept="image/*" 
                        onChange={handleImageUpload} 
                        className="hidden" 
                      />
                      <label 
                        htmlFor="image-upload"
                        className="flex flex-col items-center justify-center cursor-pointer"
                      >
                        <Upload className="w-12 h-12 text-gray-500 mb-3" />
                        <p className="text-gray-300 mb-2">Click to upload an image</p>
                        <p className="text-gray-500 text-sm">PNG, JPG, GIF up to 5MB</p>
                      </label>
                    </div>
                  ) : (
                    <div className="relative">
                      <img 
                        src={image} 
                        alt="Uploaded meme" 
                        className="rounded-lg max-h-80 mx-auto" 
                      />
                      <button 
                        type="button" 
                        onClick={clearImage}
                        className="absolute top-2 right-2 bg-dark-900/80 p-2 rounded-full text-white hover:bg-dark-700 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
                
                <div>
                  <label htmlFor="caption" className="block text-white font-medium mb-2">
                    Meme Caption
                  </label>
                  <textarea 
                    id="caption"
                    rows={3}
                    placeholder="Enter the text caption for your meme..."
                    value={caption}
                    onChange={(e) => setCaption(e.target.value)}
                    className="w-full bg-dark-900 border border-dark-600 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-accent-blue"
                  />
                </div>
                
                <div className="flex justify-center">
                  <button 
                    type="submit"
                    disabled={!image || !caption || isAnalyzing}
                    className={`button-primary flex items-center ${(!image || !caption || isAnalyzing) ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {isAnalyzing ? (
                      <>
                        <span className="mr-2">Analyzing...</span>
                        <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                      </>
                    ) : (
                      <>
                        Analyze Meme <ArrowRight className="ml-2 w-5 h-5" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
            
            {/* Results Section */}
            {result && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="mt-12 bg-dark-800 rounded-xl p-8 shadow-xl"
              >
                <h3 className="text-2xl font-bold mb-6 text-center">Virality Analysis Results</h3>
                
                <div className="mb-8 flex flex-col items-center">
                  <div className="relative mb-3">
                    <svg className="w-48 h-48">
                      <circle
                        cx="74"
                        cy="74"
                        r="64"
                        fill="transparent"
                        stroke="#2D2D2D"
                        strokeWidth="10"
                      />
                      <circle
                        cx="74"
                        cy="74"
                        r="64"
                        fill="transparent"
                        stroke={
                          result.score > 80 ? "#76FF03" :
                          result.score > 60 ? "#FFEA00" :
                          result.score > 40 ? "#FF5252" : "#F44336"
                        }
                        strokeWidth="10"
                        strokeDasharray={`${2 * Math.PI * 64 * (result.score / 100)} ${2 * Math.PI * 64 * (1 - result.score / 100)}`}
                        strokeDashoffset={2 * Math.PI * 64 * 0.25}
                        style={{ transition: 'stroke-dasharray 1s ease-in-out' }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-4xl font-bold" style={{ 
                        color: result.score > 80 ? "#76FF03" :
                              result.score > 60 ? "#FFEA00" :
                              result.score > 40 ? "#FF5252" : "#F44336"
                      }}>
                        {result.score}
                      </span>
                    </div>
                  </div>
                  <p className="text-xl text-gray-300">
                    {result.score > 80 ? "Highly Viral Potential!" :
                     result.score > 60 ? "Good Viral Potential" :
                     result.score > 40 ? "Moderate Potential" : "Limited Viral Potential"}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-dark-900 p-6 rounded-lg">
                    <div className="flex items-center mb-4">
                      <Zap className="w-6 h-6 text-accent-green mr-2" />
                      <h4 className="text-lg font-bold">Strengths</h4>
                    </div>
                    <ul className="space-y-2">
                      {result.strengths.map((strength, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-accent-green mr-2">•</span>
                          <span className="text-gray-300">{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="bg-dark-900 p-6 rounded-lg">
                    <div className="flex items-center mb-4">
                      <ArrowRight className="w-6 h-6 text-accent-yellow mr-2" />
                      <h4 className="text-lg font-bold">Improvement Areas</h4>
                    </div>
                    <ul className="space-y-2">
                      {result.improvements.map((improvement, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-accent-yellow mr-2">•</span>
                          <span className="text-gray-300">{improvement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="text-lg font-bold mb-2">Detailed Analysis</h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-dark-900 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <ImageIcon className="w-5 h-5 text-accent-blue mr-2" />
                        <h5 className="font-semibold">Visual Impact</h5>
                      </div>
                      <div className="w-full bg-dark-700 rounded-full h-2">
                        <div 
                          className="bg-accent-blue h-2 rounded-full" 
                          style={{ width: `${result.score - 5}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="bg-dark-900 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <MessageSquare className="w-5 h-5 text-accent-red mr-2" />
                        <h5 className="font-semibold">Caption Quality</h5>
                      </div>
                      <div className="w-full bg-dark-700 rounded-full h-2">
                        <div 
                          className="bg-accent-red h-2 rounded-full" 
                          style={{ width: `${result.score - 10}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="bg-dark-900 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <Zap className="w-5 h-5 text-accent-yellow mr-2" />
                        <h5 className="font-semibold">Relatability</h5>
                      </div>
                      <div className="w-full bg-dark-700 rounded-full h-2">
                        <div 
                          className="bg-accent-yellow h-2 rounded-full" 
                          style={{ width: `${result.score + 5}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="bg-dark-900 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <Clock className="w-5 h-5 text-accent-green mr-2" />
                        <h5 className="font-semibold">Timing Relevance</h5>
                      </div>
                      <div className="w-full bg-dark-700 rounded-full h-2">
                        <div 
                          className="bg-accent-green h-2 rounded-full" 
                          style={{ width: `${result.score - 15}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-dark-900 p-5 rounded-lg mt-6 border border-dark-600">
                    <h5 className="font-bold mb-2">AI Recommendation</h5>
                    <p className="text-gray-300">
                      {result.score > 80 ? 
                        "This meme shows excellent viral potential. Consider posting during peak hours (9-11am or 7-9pm) for maximum reach. The strong emotional component and clear messaging should drive high engagement." :
                       result.score > 60 ?
                        "Good potential with some adjustments. Try increasing the visual contrast and simplifying the caption. The concept is strong, but execution could be refined for better impact." :
                       result.score > 40 ?
                        "Moderate potential that needs improvement. Consider a complete revision of the caption to increase emotional impact. The visual concept works, but needs more relatability elements." :
                        "Limited viral potential in current form. We recommend rethinking the core concept and focusing more on trending topics or universal experiences that resonate with broader audiences."
                      }
                    </p>
                  </div>
                </div>
                
                <div className="mt-8 flex justify-center">
                  <button 
                    type="button"
                    onClick={() => {
                      setResult(null);
                      setImage(null);
                      setCaption('');
                    }}
                    className="button-secondary"
                  >
                    Test Another Meme
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="How The Analysis Works" 
            subtitle="Behind the Scenes"
            gradient="from-accent-green to-accent-yellow"
          />
          
          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="bg-dark-900 p-6 rounded-lg mb-6"
            >
              <p className="text-gray-300">
                In the full implementation, our model analyzes multiple dimensions of your meme:
              </p>
              
              <ul className="mt-4 space-y-3">
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">1.</span>
                  <span className="text-gray-300">
                    <strong className="text-white">Image Analysis:</strong> Computer vision evaluates visual 
                    elements, composition, contrast, color usage, and recognizable objects
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">2.</span>
                  <span className="text-gray-300">
                    <strong className="text-white">Text Analysis:</strong> NLP processes caption text for 
                    sentiment, emotional impact, humor style, and cultural references
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">3.</span>
                  <span className="text-gray-300">
                    <strong className="text-white">Context Evaluation:</strong> Compares content to current 
                    trends and viral patterns across platforms
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-blue mr-2 font-bold">4.</span>
                  <span className="text-gray-300">
                    <strong className="text-white">Audience Matching:</strong> Predicts which demographic 
                    segments are most likely to engage with your content
                  </span>
                </li>
              </ul>
            </motion.div>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-center text-gray-400"
            >
              While this demo uses simulated results, our actual model has been trained on 50,000+ 
              memes and achieves 78% accuracy in predicting viral content.
            </motion.p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TryYourself;
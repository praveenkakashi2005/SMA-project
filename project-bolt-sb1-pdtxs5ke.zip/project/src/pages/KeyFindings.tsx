import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle';
import { viralityFactors } from '../utils/memeData';
import { Check, X, Clock, TrendingUp, BarChart4 } from 'lucide-react';

const KeyFindings: React.FC = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="py-16 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Key Findings" 
            subtitle="What Makes Memes Viral"
            gradient="from-accent-yellow to-accent-green"
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <p className="text-xl text-gray-300 mb-6">
              After analyzing 50,000+ memes across major platforms, we've identified key factors 
              that consistently predict viral success.
            </p>
            <p className="text-gray-400">
              These insights reveal both surprising and expected patterns in what makes content spread.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Main Findings Infographic */}
      <section className="py-20">
        <div className="section-container">
          <div className="bg-dark-800 rounded-2xl p-8 shadow-xl">
            <h3 className="text-2xl md:text-3xl font-bold mb-8 text-center gradient-text from-accent-red to-accent-blue">
              Top Virality Factors
            </h3>
            
            <div className="space-y-6">
              {viralityFactors.map((factor, index) => (
                <motion.div 
                  key={factor.factor}
                  className="bg-dark-900 rounded-xl p-6 border border-dark-600"
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="mb-4 md:mb-0 md:mr-6 flex-1">
                      <h4 className="text-xl font-bold mb-2">{factor.factor}</h4>
                      <p className="text-gray-400">{factor.description}</p>
                    </div>
                    
                    <div className="w-full md:w-32 flex-shrink-0">
                      <div className="w-full bg-dark-600 rounded-full h-6 flex items-center">
                        <div 
                          className="h-6 rounded-full flex items-center justify-end px-2"
                          style={{ 
                            width: `${factor.importance}%`,
                            background: `linear-gradient(90deg, 
                              ${index % 4 === 0 ? '#FF5252' : 
                                index % 4 === 1 ? '#00E5FF' : 
                                index % 4 === 2 ? '#FFEA00' : '#76FF03'} 0%, 
                              ${index % 4 === 0 ? '#FF867F' : 
                                index % 4 === 1 ? '#80F2FF' : 
                                index % 4 === 2 ? '#FFF47F' : '#BEFF81'} 100%)`
                          }}
                        >
                          <span className="text-dark-900 font-bold text-sm">{factor.importance}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Viral vs. Non-Viral Comparison */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <SectionTitle 
            title="Viral vs. Non-Viral Comparison" 
            subtitle="The Differences"
            gradient="from-accent-blue to-accent-red"
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <motion.div
              className="bg-dark-900 rounded-xl p-8 border-2 border-accent-green"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-full bg-accent-green/20 flex items-center justify-center mr-4">
                  <Check className="w-6 h-6 text-accent-green" />
                </div>
                <h3 className="text-2xl font-bold text-accent-green">Viral Meme Characteristics</h3>
              </div>
              
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Emotional Intensity:</strong> Evokes strong emotional reactions (joy, surprise, outrage)
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Relatability:</strong> Connects to common experiences or current events
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Visual Simplicity:</strong> Clear focal point with minimal distractions
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Clever Twist:</strong> Uses familiar formats but with unexpected elements
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Rapid Initial Growth:</strong> Gains significant engagement in first 2 hours
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent-green mr-2">•</span>
                  <span>
                    <strong className="text-white">Cross-Platform Appeal:</strong> Performs well across different social networks
                  </span>
                </li>
              </ul>
              
              <div className="mt-8 p-4 bg-dark-800 rounded-lg">
                <p className="text-accent-green font-semibold">
                  Average engagement rate: 5.2% of viewers engage
                </p>
              </div>
            </motion.div>
            
            <motion.div
              className="bg-dark-900 rounded-xl p-8 border-2 border-error-500"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-full bg-error-500/20 flex items-center justify-center mr-4">
                  <X className="w-6 h-6 text-error-500" />
                </div>
                <h3 className="text-2xl font-bold text-error-500">Non-Viral Meme Characteristics</h3>
              </div>
              
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Emotional Neutrality:</strong> Lacks clear emotional direction or impact
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Complexity:</strong> Requires too much context or explanation to understand
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Overused Format:</strong> Replicates existing memes without adding value
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Poor Timing:</strong> Arrives too late after relevant events or trends
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Narrow Appeal:</strong> Only relevant to a very specific group or interest
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-error-500 mr-2">•</span>
                  <span>
                    <strong className="text-white">Slow Start:</strong> Fails to gain traction in first few hours of posting
                  </span>
                </li>
              </ul>
              
              <div className="mt-8 p-4 bg-dark-800 rounded-lg">
                <p className="text-error-500 font-semibold">
                  Average engagement rate: 0.8% of viewers engage
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Key Charts */}
      <section className="py-20">
        <div className="section-container">
          <SectionTitle 
            title="Virality Insights" 
            subtitle="By the Numbers"
            gradient="from-accent-green to-accent-yellow"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center mb-4">
                <Clock className="w-8 h-8 text-accent-yellow mr-3" />
                <h3 className="text-xl font-bold">Timing Impact</h3>
              </div>
              
              <div className="aspect-w-16 aspect-h-9 mb-4">
                <div className="w-full h-64 bg-dark-700 rounded-lg p-4">
                  <div className="flex h-full items-end space-x-3">
                    {[85, 76, 52, 31, 17, 8].map((height, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center">
                        <div className="w-full bg-gradient-to-t from-accent-yellow to-accent-green rounded-t-md" style={{ height: `${height}%` }}></div>
                        <div className="mt-2 text-xs text-gray-400">
                          {i === 0 ? "0-1h" : 
                           i === 1 ? "1-3h" : 
                           i === 2 ? "3-6h" : 
                           i === 3 ? "6-12h" : 
                           i === 4 ? "12-24h" : "24h+"}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <p className="text-gray-300 text-sm">
                <strong className="text-white">Finding:</strong> The likelihood of a meme going viral 
                decreases exponentially after 3 hours from initial posting. Content posted during peak 
                platform activity times (7-9am and 8-10pm) had 42% higher spread rates.
              </p>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="flex items-center mb-4">
                <TrendingUp className="w-8 h-8 text-accent-blue mr-3" />
                <h3 className="text-xl font-bold">Spread Velocity</h3>
              </div>
              
              <div className="aspect-w-16 aspect-h-9 mb-4">
                <div className="w-full h-64 bg-dark-700 rounded-lg p-4 flex items-center justify-center">
                  <div className="w-full h-3/4 relative">
                    {/* Line chart for viral vs non-viral content */}
                    <svg viewBox="0 0 100 50" className="w-full h-full">
                      {/* Grid lines */}
                      {[0, 1, 2, 3, 4].map((i) => (
                        <line 
                          key={`h-${i}`}
                          x1="0" 
                          y1={i * 12.5} 
                          x2="100" 
                          y2={i * 12.5} 
                          stroke="#3C3C3C" 
                          strokeWidth="0.5"
                        />
                      ))}
                      {[0, 1, 2, 3, 4, 5].map((i) => (
                        <line 
                          key={`v-${i}`}
                          x1={i * 20} 
                          y1="0" 
                          x2={i * 20} 
                          y2="50" 
                          stroke="#3C3C3C" 
                          strokeWidth="0.5"
                        />
                      ))}
                      
                      {/* Viral meme path */}
                      <path 
                        d="M0,50 C20,45 40,10 60,5 C80,2 100,0 100,0" 
                        fill="none" 
                        stroke="#00E5FF" 
                        strokeWidth="2"
                      />
                      
                      {/* Non-viral meme path */}
                      <path 
                        d="M0,50 C20,48 40,45 60,42 C80,40 100,38 100,38" 
                        fill="none" 
                        stroke="#FF5252" 
                        strokeWidth="2"
                      />
                    </svg>
                    
                    <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-gray-400">
                      <span>1h</span>
                      <span>6h</span>
                      <span>12h</span>
                      <span>24h</span>
                      <span>48h</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center space-x-6 mb-3">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-accent-blue rounded-full mr-2"></div>
                  <span className="text-sm text-gray-300">Viral Content</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-accent-red rounded-full mr-2"></div>
                  <span className="text-sm text-gray-300">Non-Viral Content</span>
                </div>
              </div>
              
              <p className="text-gray-300 text-sm">
                <strong className="text-white">Finding:</strong> Viral memes show a distinctive 
                "hockey stick" growth pattern in the first 6 hours. If a meme reaches 10,000+ 
                engagements within the first 3 hours, it has a 72% chance of exceeding 100,000 total engagements.
              </p>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="flex items-center mb-4">
                <BarChart4 className="w-8 h-8 text-accent-red mr-3" />
                <h3 className="text-xl font-bold">Content Type Performance</h3>
              </div>
              
              <div className="aspect-w-16 aspect-h-9 mb-4">
                <div className="w-full h-64 bg-dark-700 rounded-lg p-4">
                  <div className="h-full flex items-end space-x-4">
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-gradient-to-t from-accent-red to-accent-yellow rounded-t-md" style={{ height: '78%' }}></div>
                      <div className="mt-2 text-xs text-gray-400">Humor</div>
                      <div className="text-white text-xs mt-1">78%</div>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-gradient-to-t from-accent-red to-accent-yellow rounded-t-md" style={{ height: '65%' }}></div>
                      <div className="mt-2 text-xs text-gray-400">Relatable</div>
                      <div className="text-white text-xs mt-1">65%</div>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-gradient-to-t from-accent-red to-accent-yellow rounded-t-md" style={{ height: '57%' }}></div>
                      <div className="mt-2 text-xs text-gray-400">Current</div>
                      <div className="text-white text-xs mt-1">57%</div>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-gradient-to-t from-accent-red to-accent-yellow rounded-t-md" style={{ height: '42%' }}></div>
                      <div className="mt-2 text-xs text-gray-400">Shocking</div>
                      <div className="text-white text-xs mt-1">42%</div>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-gradient-to-t from-accent-red to-accent-yellow rounded-t-md" style={{ height: '36%' }}></div>
                      <div className="mt-2 text-xs text-gray-400">Cute</div>
                      <div className="text-white text-xs mt-1">36%</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <p className="text-gray-300 text-sm">
                <strong className="text-white">Finding:</strong> Humor-based memes consistently 
                outperform other content types, with relatable content coming in second. 
                Content combining humor with current events showed the highest viral potential.
              </p>
            </motion.div>
            
            <motion.div
              className="bg-dark-800 rounded-xl p-6 shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <h3 className="text-xl font-bold mb-4">Platform-Specific Insights</h3>
              
              <div className="space-y-4">
                <div className="p-3 bg-dark-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-accent-blue">Twitter/X</span>
                    <span className="text-sm text-gray-400">Avg. Lifespan: 18 hours</span>
                  </div>
                  <p className="text-sm text-gray-300">
                    Topical humor and news-related content perform best. Text-heavy memes show higher engagement.
                  </p>
                </div>
                
                <div className="p-3 bg-dark-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-accent-red">Instagram</span>
                    <span className="text-sm text-gray-400">Avg. Lifespan: 36 hours</span>
                  </div>
                  <p className="text-sm text-gray-300">
                    Visually appealing content with relatable themes performs best. Carousel posts show higher retention.
                  </p>
                </div>
                
                <div className="p-3 bg-dark-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-accent-yellow">Reddit</span>
                    <span className="text-sm text-gray-400">Avg. Lifespan: 48 hours</span>
                  </div>
                  <p className="text-sm text-gray-300">
                    Niche, clever humor performs best. Community-specific references increase engagement significantly.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Conclusion */}
      <section className="py-20 bg-dark-800">
        <div className="section-container">
          <motion.div
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl font-bold mb-6 gradient-text from-accent-blue to-accent-yellow">
              Summary of Key Findings
            </h2>
            <p className="text-xl text-gray-300 mb-6">
              Our research demonstrates that meme virality is not random—it follows predictable patterns 
              that can be identified and replicated.
            </p>
            <p className="text-gray-400 mb-8">
              The most successful memes combine emotional impact, cultural relevance, and visual simplicity 
              with precise timing. While content quality matters, the context and timing of posting often 
              have an even greater impact on a meme's viral potential.
            </p>
            <div className="p-6 bg-dark-900 rounded-xl border border-dark-600">
              <p className="text-accent-green font-medium">
                These insights formed the foundation of our predictive model, which can now forecast 
                a meme's potential virality with 78% accuracy before it's even posted.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default KeyFindings;
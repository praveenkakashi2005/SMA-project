import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import Home from './pages/Home';
import About from './pages/About';
import DataCollection from './pages/DataCollection';
import FeaturesAnalyzed from './pages/FeaturesAnalyzed';
import KeyFindings from './pages/KeyFindings';
import PredictionModel from './pages/PredictionModel';
import TryYourself from './pages/TryYourself';
import Conclusion from './pages/Conclusion';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/data-collection" element={<DataCollection />} />
          <Route path="/features-analyzed" element={<FeaturesAnalyzed />} />
          <Route path="/key-findings" element={<KeyFindings />} />
          <Route path="/prediction-model" element={<PredictionModel />} />
          <Route path="/try-yourself" element={<TryYourself />} />
          <Route path="/conclusion" element={<Conclusion />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;